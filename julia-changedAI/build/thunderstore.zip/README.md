# Changed Mob AI

Goal is to add some simple changed to mob behavior, such as changing movement speed or how they see. 

Mod by @kapchj on github.
Default icon by @lilujk on github.