# Funny Jump Mod

A mod which makes jump height random. Either you jump super high, or super low!
Mod by @MaxAndCheese on github. 
Default icon by @lilujk on github.