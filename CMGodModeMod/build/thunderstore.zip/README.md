# CM God Mode Mod

This mod adds God Mode features to the game. These features include:

- unlimited number of days to meet the quota
- unlimited amount of starting credits
- infinite sprint
- higher jumping
- invincibility

This mod is still a work-in-progress mod!

Created by Christian Marinkovich

Default icon by @lilujk on github.