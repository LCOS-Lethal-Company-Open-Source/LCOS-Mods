# moreCash Mod

Gives your team 1000 starting cash at the beginning of a round.
Rensselaer Center for Open Source (RCOS) Project.
Created by @BastedEggsRYummy on github.
Default icon by @lilujk on github.