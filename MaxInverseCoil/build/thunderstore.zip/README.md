# Inverse Coilhead

A mod which changes the coilhead's behavior so that it moves only when a player is looking at it.

Code by @MaxAndCheese on github. 
Default icon by @lilujk on github.