# CM Scooby Laugh Sound Mod

This mod adds in a Sooby Laugh sound effect to the game that is played everytime the player enters a new game.
This mod is still a work in progress and may have several bugs!

Created by Christian Marinkovich (@Christian2147 on github)

Default icon by @lilujk on github.